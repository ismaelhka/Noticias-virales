function verNoticia() {
    alert("Esta funcionalidad estará disponible pronto.");
}
